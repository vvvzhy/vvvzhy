[



{"name":"［github双源logo］","url":"https://ghp.ci/https://raw.githubusercontent.com/qq859/cj/main/%E8%99%8E%E6%96%97%E6%AD%AAlogo.m3u","ua":"okhttp/3.15","logo":"https://github.moeyy.xyz/https://raw.githubusercontent.com/qq859/cj/main/%E5%9B%BE%E7%89%87/HYDIY800X1200.png"},


{"name":"［影视歌曲］","url":"./EXT/影视歌曲.m3u","ua":"okhttp/3.15","logo":"https://github.moeyy.xyz/https://raw.githubusercontent.com/qq859/cj/main/%E5%9B%BE%E7%89%87/HYDIY800X1200.png"}




]