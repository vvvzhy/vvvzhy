[

{"name":"虎斗歪［码云加密］","url":"https://gitee.com/yu_shan_fei/zby/raw/master/TV/%E8%99%8E%E6%96%97%E6%AD%AA.m3u","group":1},
{"name":"虎斗歪［github］","url":"https://ghp.ci/https://raw.githubusercontent.com/qq859/cj/main/%E8%99%8E%E7%89%99%E6%96%97%E9%B1%BC%E6%AD%AA%E6%AD%AA.txt","group":1},

{"name":"😍仙女8o_V6","url":"https://ghp.ci/https://raw.githubusercontent.com/Fairy8o/IPTV/main/PDX-V6.txt"},
{"name":"😍仙女8o_V4","url":"https://ghp.ci/https://raw.githubusercontent.com/xzw832/cmys/21277b2fafe74c542f067d9c4ee4f742ad9000c3/Z_15_weishi.txt"},

{"name":"IPV6~范明明转实时更新","url":"https://fanmingming.com/txt?url=https://raw.githubusercontent.com/MercuryZz/IPTVN/Files/IPTV.m3u"},

{"name":"1小时更新txt","url":"https://ghp.ci/https://raw.githubusercontent.com/fenxp/iptv/main/live/ipv6.txt"},
{"name":"1小时更新M3U","url":"https://ghp.ci/https://raw.githubusercontent.com/fenxp/iptv/main/live/ipv6.m3u"},
{"name":"范明明转1小时更新","url":"https://fanmingming.com/txt?url=https://raw.githubusercontent.com/fenxp/iptv/main/live/ipv6.m3u"},
{"name":"合并的输出TXT","url":"https://ghp.ci/https://raw.githubusercontent.com/cymz6/AutoIPTV/main/merged_output.txt"},
{"name":"实时更新txt","url":"https://ghp.ci/https://raw.githubusercontent.com/xxoo-qx/IPTV/main/IPTV.txt"},
{"name":"实时更新M3U","url":"https://ghp.ci/https://raw.githubusercontent.com/xxoo-qx/IPTV/main/IPTV.m3u"},

{"name":"范明明转随缘更新","url":"https://fanmingming.com/txt?url=https://raw.githubusercontent.com/gnodgl/IPTV/master/IPTV.m3u"},
{"name":"实时更新ipv4","url":"https://ghp.ci/https://raw.githubusercontent.com/xxoo-qx/IPTV/main/itv.txt"},
{"name":"临时IPV4","url":"https://ghp.ci/https://raw.githubusercontent.com/110COM/repo/83546eb1740e1eb4b825852208ef8a3f0523cb2a/dk/mut"},
{"name":"ipv4组播","url":"https://ghp.ci/https://raw.githubusercontent.com/outcastveron/tv/387222aaa518f54244ce5ff438c6b7e29e0a4d12/live.txt"},
{"name":"V6V4地区广播","url":"https://ghp.ci/https://raw.githubusercontent.com/youngking525/xiaopowanleng/b7b4bba569f22d7174845c1f7f64d2460dec889d/YanG.m3u"},
{"name":"😍v4v6随缘","url":"https://ghp.ci/https://raw.githubusercontent.com/xzw832/cmys/21277b2fafe74c542f067d9c4ee4f742ad9000c3/IPV6.txt"},


{"name":"V4秒更","url":"https://ghp.ci/https://raw.githubusercontent.com/longlonglaile2/tv/bacc92cc92b9314297f41a5811ebc49b6426ff98/itvlist.txt"},
{"name":"空的请添加","url":"https://ghp.ci/"},
{"name":"空的请添加","url":"https://ghp.ci/"},
{"name":"空的请添加","url":"https://ghp.ci/"},
{"name":"空的请添加","url":"https://ghp.ci/"},
{"name":"空的请添加","url":"https://ghp.ci/"},
{"name":"空的请添加","url":"https://ghp.ci/"},
{"name":"空的请添加","url":"https://ghp.ci/"},
{"name":"空的请添加","url":"https://ghp.ci/"}



]