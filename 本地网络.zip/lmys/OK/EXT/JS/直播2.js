[



{"name":"洪宇-每天自动更新","url":"https://gh.idayer.com/https://raw.githubusercontent.com/mlvjfchen/TV/main/iptv_list.txt&&&https://tuapi.eees.cc/api.php?category=meinv&type=302"},
{"name":"每天自动更新1次","url":"https://gh.idayer.com/https://raw.githubusercontent.com/Guovin/TV/gd/result.txt&&&https://tuapi.eees.cc/api.php?category=meinv&type=302&&&https://tuapi.eees.cc/api.php?category=meinv&type=302"},
{"name":"每天自动更新1次","url":"https://gh.idayer.com/https://raw.githubusercontent.com/ssili126/tv/main/itvlist.txt&&&https://tuapi.eees.cc/api.php?category=meinv&type=302"},
{"name":"洪宇丨IPTV","url":"https://m3u.ibert.me/txt/ycl_iptv.txt&&&https://tuapi.eees.cc/api.php?category=meinv&type=302"},
{"name":"洪宇丨IPTV","url":"https://m3u.ibert.me/txt/y_g.txt&&&https://tuapi.eees.cc/api.php?category=meinv&type=302"},
{"name":"洪宇丨IPTV","url":"https://m3u.ibert.me/txt/j_home.txt&&&https://tuapi.eees.cc/api.php?category=meinv&type=302"},
{"name":"洪宇丨IPTV","url":"https://gh.idayer.com/https://raw.githubusercontent.com/gaotianliuyun/gao/master/list.txt&&&https://tuapi.eees.cc/api.php?category=meinv&type=302"},
{"name":"洪宇丨IPTV","url":"https://gitee.com/xxy002/zhiboyuan/raw/master/zby.txt&&&https://tuapi.eees.cc/api.php?category=meinv&type=302"},
{"name":"轮播","url":"https://gitlab.com/p2v5/wangtv/-/raw/main/lunbo.txt&&&https://tuapi.eees.cc/api.php?category=meinv&type=302"},




{"name":"轮播","url":"https://raw.githubusercontent.com/yuanzl77/IPTV/main/直播/央视频道.txt&&&https://tuapi.eees.cc/api.php?category=meinv&type=302"},
{"name":"轮播","url":"http://120.79.4.185/new/mdlive.txt&&&https://tuapi.eees.cc/api.php?category=meinv&type=302"},
{"name":"轮播","url":"https://raw.githubusercontent.com/Fairy8o/IPTV/main/DIYP-v4.txt&&&https://tuapi.eees.cc/api.php?category=meinv&type=302"},
{"name":"轮播","url":"https://tv.youdu.fan:666/live/&&&https://tuapi.eees.cc/api.php?category=meinv&type=302"},
{"name":"轮播","url":"https://fs-im-kefu.7moor-fs1.com/ly/4d2c3f00-7d4c-11e5-af15-41bf63ae4ea0/1715581924111/live1.txt&&&https://tuapi.eees.cc/api.php?category=meinv&type=302"},
{"name":"轮播","url":"https://raw.githubusercontent.com/Guovin/TV/gd/result.txt&&&https://tuapi.eees.cc/api.php?category=meinv&type=302"},
{"name":"轮播","url":"https://raw.githubusercontent.com/PizazzGY/TVBox_warehouse/main/live.txt&&&https://tuapi.eees.cc/api.php?category=meinv&type=302"},
{"name":"轮播","url":"https://raw.githubusercontent.com/yuanzl77/IPTV/main/直播/ipv6.txt&&&https://tuapi.eees.cc/api.php?category=meinv&type=302"},
{"name":"轮播","url":"https://raw.githubusercontent.com/ssili126/tv/main/itvlist.txt&&&https://tuapi.eees.cc/api.php?category=meinv&type=302"},


{"name":"春盈天下","url":"http://120.24.204.74:1888/?explorer/share/file&hash=8eaa3XwtywyAg-02R9sIhwj8jhTViR46btHi7m935rp0-6R7tZscuft_UGBA2aFvmw&name=/%E6%98%A5%E7%9B%88%E5%A4%A9%E4%B8%8B%E6%96%B0ds.css&&&https://tuapi.eees.cc/api.php?category=meinv&type=302"}



]