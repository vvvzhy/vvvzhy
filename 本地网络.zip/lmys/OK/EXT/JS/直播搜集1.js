[
{"name":"合并的输出M3U","url":"https://gh.idayer.com/https://raw.githubusercontent.com/cymz6/AutoIPTV/main/merged_output.m3u"},
{"name":"合并的输出TXT","url":"https://gh.idayer.com/https://raw.githubusercontent.com/cymz6/AutoIPTV/main/merged_output.txt"},
{"name":"空的请添加","url":"https://agit.ai/n3rd/N3RD/raw/branch/master/JN/tv.txt"},
{"name":"空的请添加","url":"https://agit.ai/n3rd/N3RD/raw/branch/master/JN/tv.txt"},
{"name":"空的请添加","url":"https://agit.ai/n3rd/N3RD/raw/branch/master/JN/tv.txt"},
{"name":"空的请添加","url":"https://agit.ai/n3rd/N3RD/raw/branch/master/JN/tv.txt"},
{"name":"空的请添加","url":"https://agit.ai/n3rd/N3RD/raw/branch/master/JN/tv.txt"},
{"name":"空的请添加","url":"https://agit.ai/n3rd/N3RD/raw/branch/master/JN/tv.txt"},
{"name":"空的请添加","url":"https://agit.ai/n3rd/N3RD/raw/branch/master/JN/tv.txt"},
{"name":"空的请添加","url":"https://agit.ai/n3rd/N3RD/raw/branch/master/JN/tv.txt"},
{"name":"空的请添加","url":"https://agit.ai/n3rd/N3RD/raw/branch/master/JN/tv.txt"},
{"name":"空的请添加","url":"https://agit.ai/n3rd/N3RD/raw/branch/master/JN/tv.txt"},
{"name":"空的请添加","url":"https://agit.ai/n3rd/N3RD/raw/branch/master/JN/tv.txt"},
{"name":"空的请添加","url":"https://agit.ai/n3rd/N3RD/raw/branch/master/JN/tv.txt"},
{"name":"空的请添加","url":"https://agit.ai/n3rd/N3RD/raw/branch/master/JN/tv.txt"},
{"name":"空的请添加","url":"https://agit.ai/n3rd/N3RD/raw/branch/master/JN/tv.txt"},
{"name":"空的请添加","url":"https://agit.ai/n3rd/N3RD/raw/branch/master/JN/tv.txt"},
{"name":"空的请添加","url":"https://agit.ai/n3rd/N3RD/raw/branch/master/JN/tv.txt"},
{"name":"空的请添加","url":"https://agit.ai/n3rd/N3RD/raw/branch/master/JN/tv.txt"},
{"name":"空的请添加","url":"https://agit.ai/n3rd/N3RD/raw/branch/master/JN/tv.txt"},
{"name":"空的请添加","url":"https://agit.ai/n3rd/N3RD/raw/branch/master/JN/tv.txt"},
{"name":"空的请添加","url":"https://agit.ai/n3rd/N3RD/raw/branch/master/JN/tv.txt"},
{"name":"空的请添加","url":"https://agit.ai/n3rd/N3RD/raw/branch/master/JN/tv.txt"},
{"name":"空的请添加","url":"https://agit.ai/n3rd/N3RD/raw/branch/master/JN/tv.txt"}



]