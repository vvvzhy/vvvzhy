[



{"name":"空的请添加","url":"https://gh.idayer.com/https://raw.githubusercontent.com/mlvjfchen/TV/main/iptv_list.txt","group":1},
{"name":"空的请添加","url":"https://gh.idayer.com/https://raw.githubusercontent.com/mlvjfchen/TV/main/iptv_list.txt","group":1},
{"name":"空的请添加","url":"https://gh.idayer.com/https://raw.githubusercontent.com/mlvjfchen/TV/main/iptv_list.txt","group":1},
{"name":"空的请添加","url":"https://gh.idayer.com/https://raw.githubusercontent.com/mlvjfchen/TV/main/iptv_list.txt","group":1},
{"name":"空的请添加","url":"https://gh.idayer.com/https://raw.githubusercontent.com/mlvjfchen/TV/main/iptv_list.txt","group":1},
{"name":"空的请添加","url":"https://gh.idayer.com/https://raw.githubusercontent.com/mlvjfchen/TV/main/iptv_list.txt","group":1},
{"name":"空的请添加","url":"https://gh.idayer.com/https://raw.githubusercontent.com/mlvjfchen/TV/main/iptv_list.txt","group":1},
{"name":"空的请添加","url":"https://gh.idayer.com/https://raw.githubusercontent.com/mlvjfchen/TV/main/iptv_list.txt","group":1},
{"name":"空的请添加","url":"https://gh.idayer.com/https://raw.githubusercontent.com/mlvjfchen/TV/main/iptv_list.txt","group":1},
{"name":"空的请添加","url":"https://gh.idayer.com/https://raw.githubusercontent.com/mlvjfchen/TV/main/iptv_list.txt","group":1},
{"name":"空的请添加","url":"https://gh.idayer.com/https://raw.githubusercontent.com/mlvjfchen/TV/main/iptv_list.txt","group":1},
{"name":"空的请添加","url":"https://gh.idayer.com/https://raw.githubusercontent.com/mlvjfchen/TV/main/iptv_list.txt","group":1}
]