[

{"name":"［github双源logo］","url":"https://ghp.ci/https://raw.githubusercontent.com/qq859/cj/main/%E8%99%8E%E6%96%97%E6%AD%AAlogo.m3u","ua":"okhttp/3.15","logo":"https://github.moeyy.xyz/https://raw.githubusercontent.com/qq859/cj/main/%E5%9B%BE%E7%89%87/HYDIY800X1200.png"},



{"name":"lPTV-lPTV6","url":"https://ghp.ci/https://raw.githubusercontent.com/vbskycn/iptv/refs/heads/master/tv/iptv6.txt","ua":"okhttp/3.15","logo":"https://github.moeyy.xyz/https://raw.githubusercontent.com/qq859/cj/main/%E5%9B%BE%E7%89%87/HYDIY800X1200.png"},
{"name":"lPTV-lPTV4","url":"https://ghp.ci/https://raw.githubusercontent.com/vbskycn/iptv/refs/heads/master/tv/iptv4.txt","ua":"okhttp/3.15","logo":"https://github.moeyy.xyz/https://raw.githubusercontent.com/qq859/cj/main/%E5%9B%BE%E7%89%87/HYDIY800X1200.png"},

{"name":"mirror.ghproxy.com","url":"https://ghp.ci/","ua":"okhttp/3.15","logo":"https://github.moeyy.xyz/https://raw.githubusercontent.com/qq859/cj/main/%E5%9B%BE%E7%89%87/HYDIY800X1200.png"},






{"name":"［码云加密双源logo］","url":"https://gitee.com/yu_shan_fei/zby/raw/master/TV/%E8%99%8E%E6%96%97%E6%AD%AA.m3u","ua":"okhttp/3.15","logo":"https://github.moeyy.xyz/https://raw.githubusercontent.com/qq859/cj/main/%E5%9B%BE%E7%89%87/HYDIY800X1200.png"},

{"name":"虎斗歪［github］","url":"https://ghp.ci/https://raw.githubusercontent.com/qq859/cj/main/%E8%99%8E%E7%89%99%E6%96%97%E9%B1%BC%E6%AD%AA%E6%AD%AA.txt","group":1},



{"name":"IPV6-每天自动更新","type":0,"url":"https://fanmingming.com/txt?url=https://raw.githubusercontent.com/MercuryZz/IPTVN/Files/IPTV.m3u","group":1},
{"name":"陈文彬每日更新两次","url":"https://ghp.ci/https://raw.githubusercontent.com/mlvjfchen/TV/main/iptv_list.txt","group":1},

{"name":"洪宇-每天自动更新","url":"https://ghp.ci/https://raw.githubusercontent.com/mlvjfchen/TV/main/iptv_list.txt","group":1},
{"name":"每天自动更新1次","url":"https://ghp.ci/https://raw.githubusercontent.com/Guovin/TV/gd/result.txt","group":1},
{"name":"每天自动更新1次","url":"https://ghp.ci/https://raw.githubusercontent.com/ssili126/tv/main/itvlist.txt","group":1},
{"name":"自动更新合并","url":"https://ghp.ci/https://raw.githubusercontent.com/kimwang1978/collect-tv-txt/main/others_output.txt","group":1},
{"name":"自动更新其他TXT","url":"https://ghp.ci/https://raw.githubusercontent.com/kimwang1978/collect-tv-txt/main/merged_output.txt","group":1},
{"name":"自动更新其他M3U","url":"https://ghp.ci/https://raw.githubusercontent.com/kimwang1978/collect-tv-txt/main/merged_output.m3u","group":1},



{"name":"洪宇丨M3U","url":"https://ghp.ci/https://raw.githubusercontent.com/yuanzl77/IPTV/main/live.m3u","group":1},
{"name":"洪宇丨TXT","url":"https://ghp.ci/https://raw.githubusercontent.com/yuanzl77/IPTV/main/live.txt","group":1},
{"name":"洪宇丨测试1","url":"http://weixine.net/tv/ysclive.txt","group":1},
{"name":"洪宇丨ipv6+4","url":"https://ghp.ci/https://raw.githubusercontent.com/4yt1k/TVBox/main/m3u/ipv6.txt","group":1},
{"name":"洪宇丨测试2","url":"https://ghp.ci/https://raw.githubusercontent.com/sr1cky/TVBOX/main/IPTV-tvbox.txt","group":1},
{"name":"轮播","url":"https://gitlab.com/p2v5/wangtv/-/raw/main/lunbo.txt","group":1},




{"name":"轮播","url":"https://ghp.ci/https://raw.githubusercontent.com/yuanzl77/IPTV/main/直播/央视频道.txt","group":1},
{"name":"轮播","url":"http://120.79.4.185/new/mdlive.txt","group":1},
{"name":"轮播","url":"https://ghp.ci/https://raw.githubusercontent.com/Fairy8o/IPTV/main/DIYP-v4.txt","group":1},
{"name":"轮播","url":"https://tv.youdu.fan:666/live/","group":1},
{"name":"放牛娃","url":"https://fs-im-kefu.7moor-fs1.com/ly/4d2c3f00-7d4c-11e5-af15-41bf63ae4ea0/1715581924111/live1.txt","group":1},
{"name":"轮播","url":"https://ghp.ci/https://raw.githubusercontent.com/Guovin/TV/gd/result.txt","group":1},
{"name":"轮播","url":"https://ghp.ci/https://raw.githubusercontent.com/PizazzGY/TVBox_warehouse/main/live.txt","group":1},
{"name":"轮播","url":"https://ghp.ci/https://raw.githubusercontent.com/yuanzl77/IPTV/main/直播/ipv6.txt","group":1},
{"name":"轮播","url":"https://ghp.ci/https://raw.githubusercontent.com/ssili126/tv/main/itvlist.txt","group":1},

{"name":"洪宇-每天自动更新","url":"https://ghp.ci/https://raw.githubusercontent.com/yuanzl77/IPTV/main/%E7%9B%B4%E6%92%AD/%E5%A4%AE%E8%A7%86%E9%A2%91%E9%81%93.txt","group":1},
{"name":"洪宇-每天自动更新","url":"http://120.79.4.185/new/mdlive.txt","group":1},
{"name":"洪宇-每天自动更新","url":"https://ghp.ci/https://raw.githubusercontent.com/Fairy8o/IPTV/main/DIYP-v4.txt","group":1},
{"name":"洪宇-每天自动更新","url":"https://tv.youdu.fan:666/live/","group":1},
{"name":"洪宇-每天自动更新","url":"http://175.178.251.183:6689/livv.txt","group":1},
{"name":"洪宇-每天自动更新","url":"https://fs-im-kefu.7moor-fs1.com/ly/4d2c3f00-7d4c-11e5-af15-41bf63ae4ea0/1715581924111/live1.txt","group":1},
{"name":"洪宇-每天自动更新","url":"http://rihou.cc:88/hccx/zb.txt","group":1},
{"name":"洪宇-每天自动更新","url":"https://ghp.ci/https://raw.githubusercontent.com/Guovin/TV/gd/result.txt","group":1},
{"name":"洪宇-每天自动更新","url":"https://ghp.ci/https://raw.githubusercontent.com/PizazzGY/TVBox_warehouse/main/live.txt","group":1},
{"name":"洪宇-每天自动更新","url":"https://ghp.ci/https://raw.githubusercontent.com/yuanzl77/IPTV/main/直播/ipv6.txt","group":1},
{"name":"洪宇-每天自动更新","url":"https://ghp.ci/https://raw.githubusercontent.com/ssili126/tv/main/itvlist.txt","group":1},


{"name":"春盈天下","url":"http://120.24.204.74:1888/?explorer/share/file&hash=8eaa3XwtywyAg-02R9sIhwj8jhTViR46btHi7m935rp0-6R7tZscuft_UGBA2aFvmw&name=/%E6%98%A5%E7%9B%88%E5%A4%A9%E4%B8%8B%E6%96%B0ds.css","group":1}



]